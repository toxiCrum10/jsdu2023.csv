# skriptovacie-jazyky-2023-po
skriptovacie-jazyky-2023-po
